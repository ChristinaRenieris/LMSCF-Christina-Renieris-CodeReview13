<?php

namespace App\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\Events;

//importing input types
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class EventsController extends AbstractController
{
    //homepage
    /**
     * @Route("/", name="home_page")
     */
    public function showAction()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
        return $this->render('events/index.html.twig', array('events'=>$events));
    }


    //detailspage
    /**
     * @Route("/details/{id}", name="details_page")
     */
    public function detailsAction($id)
    {
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
        return $this->render('events/details.html.twig', array('event' => $event));
    }

    
    //createpage
    /**
    * @Route("/create", name="create_page")
    */
    public function createAction(Request $request)
    {
    
        $event = new Events;
        
        $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('contactEmail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('contactNumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', ChoiceType::class, array('choices'=>array('Theater'=>'Theater', 'Sport'=>'Sport', 'Music'=>'Music', 'Movie'=>'Movie'),'attr' => array('class'=>  'form-control', 'style'=>'margin-botton:15px')))
        ->add('DateTime', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
        ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'create btn', 'style'=>'margin-bottom:15px')))
        ->getForm();
        $form->handleRequest($request);
       

        if($form->isSubmitted() && $form->isValid())
        {
           

           $name = $form['name']->getData();
           $image = $form['image']->getData();
           $description = $form['description']->getData();
           $capacity = $form['capacity']->getData();
           $contactEmail = $form['contactEmail']->getData();
           $contactNumber = $form['contactNumber']->getData();
           $address = $form['address']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           $DateTime = $form['DateTime']->getData();
           
           
           $event->setName($name);
           $event->setImage($image);
           $event->setDescription($description);
           $event->setCapacity($capacity);
           $event->setContactEmail($contactEmail);
           $event->setContactNumber($contactNumber);
           $event->setAddress($address);
           $event->setUrl($url);
           $event->setType($type);
           $event->setDateTime($DateTime);

           $em = $this->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'event Added'
                   );
           return $this->redirectToRoute('home_page');
        }
       return $this->render('events/create.html.twig', array('form' => $form->createView()));
    }


    //edit
    /**
    * @Route("/edit/{id}", name="edit_page")
    */
    public function editAction( $id, Request $request){
        
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);

        
        $event->setName($event->getName());
        $event->setImage($event->getImage());
        $event->setDescription($event->getDescription());
        $event->setCapacity($event->getCapacity());
        $event->setContactEmail($event->getContactEmail());
        $event->setContactNumber($event->getContactNumber());
        $event->setAddress($event->getAddress());
        $event->setUrl($event->getUrl());
        $event->setType($event->getType());
        $event->setDateTime($event->getDateTime());
            

        $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('contactEmail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('contactNumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', ChoiceType::class, array('choices'=>array('Theater'=>'Theater', 'Sport'=>'Sport', 'Music'=>'Music', 'Movie'=>'Movie'),'attr' => array('class'=>  'form-control', 'style'=>'margin-botton:15px')))
        ->add('DateTime', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
        ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'edit btn', 'style'=>'margin-bottom:15px')))
        ->getForm();

            $form->handleRequest($request);
            if($form->isSubmitted() && $form->isValid()){
                
                $name = $form['name']->getData();
                $image = $form['image']->getData();
                $description = $form['description']->getData();
                $capacity = $form['capacity']->getData();
                $contactEmail = $form['contactEmail']->getData();
                $contactNumber = $form['contactNumber']->getData();
                $address = $form['address']->getData();
                $url = $form['url']->getData();
                $type = $form['type']->getData();
                $DateTime = $form['DateTime']->getData();

                $em = $this->getDoctrine()->getManager();
                $event = $em->getRepository('App:Events')->find($id);

                $event->setName($name);
                $event->setImage($image);
                $event->setDescription($description);
                $event->setCapacity($capacity);
                $event->setContactEmail($contactEmail);
                $event->setContactNumber($contactNumber);
                $event->setAddress($address);
                $event->setUrl($url);
                $event->setType($type);
                $event->setDateTime($DateTime);
               
                $em->flush();
                $this->addFlash(
                           'notice',
                           'Event Updated'
                           );
                return $this->redirectToRoute('home_page');
            }
        return $this->render('events/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
    }


    //delete
    /**
    * @Route("/delete/{id}", name="delete_page")
    */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository('App:Events')->find($id);
        $em->remove($event);
        $em->flush();
        $this->addFlash(
           'notice',
           'Event Removed'
           );
        return $this->redirectToRoute('home_page');
    }


    //theater
    /**
    * @Route("/theater", name="theater_page")
    */
    public function displayTheater(){
        $events = $this->getDoctrine()->getRepository
        (Events::class)->findBy(array('type' => 'Theater'));

        return $this->render('events/theater.html.twig', array('events' => $events));
    }


    //sport
    /**
    * @Route("/sport", name="sport_page")
    */
    public function displaySport(){
        $events = $this->getDoctrine()->getRepository
        (Events::class)->findBy(array('type' => 'Sport'));

        return $this->render('events/sport.html.twig', array('events' => $events));
    }


    //music
    /**
    * @Route("/music", name="music_page")
    */
    public function displayMusic(){
        $events = $this->getDoctrine()->getRepository
        (Events::class)->findBy(array('type' => 'Music'));

        return $this->render('events/music.html.twig', array('events' => $events));
    }


    //movie
    /**
    * @Route("/movie", name="movie_page")
    */
    public function displayMovie(){
        $events = $this->getDoctrine()->getRepository
        (Events::class)->findBy(array('type' => 'Movie'));

        return $this->render('events/movie.html.twig', array('events' => $events));
    }
}
